com_newsworld version 1.0.0  is a free software which is developed by kwproductions Co. 
https://kwproductions121.ir.
It includes a component newsworl extension to create news, employ code mirror editor
to be able to save images with ABSOLUTE path in src attribute of <img > so that the news
will show the images.
Plugin sendnewsworld shall be enabled auto. yet check from the plugins list in the backend.
The last created news is the default to be sent but you may change it from the plugin side.
It is written for Joomla 5.x and Joomla 6.x.
download :https://www.extensions.kwproductions121.com/mycomponents/debate-download.html
In case of any problem contact me at:
webarchitect@kwproductions121.ir
mezmer121@gmail.com
Long live Science
