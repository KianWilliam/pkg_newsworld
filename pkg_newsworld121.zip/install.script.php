<?php 
defined('_JEXEC') or die('Restricted access');


/*
 * @package newsworld for Joomla! 5.x, 6.x
 * @version $Id: plg_sendnewsworld 1.0.0 2026-07-13 23:26:33Z $
 * @author KWProductions Co.
 * @copyright (C) 2026- KWProductions Co.
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 
 This file is part of Package Newsworld.
    newsworld is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    newsworld is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with newsworld.  If not, see <http://www.gnu.org/licenses/>. 
*/

?>
<?php
use Joomla\CMS\Factory;
class pkg_NewsworldInstallerScript
{
 public function install($parent)
 {  
   
  $db  = Factory::getDbo();
  $query = $db->getQuery(true);
  $query->update('#__extensions');
  $query->set($db->quoteName('enabled') . ' = 1');
  $query->where($db->quoteName('element') . ' = ' . $db->quote('sendnewsworld'));
  $query->where($db->quoteName('type') . ' = ' . $db->quote('plugin'));
  $db->setQuery($query);
  $db->execute();
  
 }
   public function uninstall($parent) 
  {
	       
       
  }
}
